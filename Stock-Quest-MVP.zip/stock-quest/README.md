# Stock Quest

MVP académico de capacitación en inventarios y logística. React 18 + TypeScript + Zustand + React Router + TailwindCSS + Lucide; Phaser 3 desacoplado; API Express + JWT/Bearer + bcrypt; Prisma con proveedor MySQL.

## Inicio local

Requisitos: Node.js 22.18 o superior y MySQL 8, o MariaDB incluido en XAMPP. Mantén la base de datos en una instancia de desarrollo.

1. Ejecuta `npm ci` desde esta carpeta.
2. Copia `apps/api/.env.example` a `apps/api/.env`. Configura `DATABASE_URL`, un `JWT_SECRET` aleatorio de al menos 32 caracteres y `FRONTEND_URL=http://localhost:5173`.
3. Crea una base vacía para el proyecto. Con Docker puedes usar `compose.yaml`: define `MYSQL_PASSWORD` y `MYSQL_ROOT_PASSWORD` en tu entorno y ejecuta `docker compose up -d`.
4. Ejecuta `npm run db:generate`, `npm run db:migrate` y `npm run db:seed`.
5. Ejecuta `npm run dev`. Abre la URL indicada por Vite. La API usa el puerto 4000.
6. Registra una cuenta de aprendiz desde la interfaz. Para los otros roles, configura `SEED_ADMIN_EMAIL`, `SEED_ADMIN_PASSWORD`, `SEED_LEADER_EMAIL` y `SEED_LEADER_PASSWORD` antes de ejecutar el seed.

El seed no sobrescribe cuentas ni contenido existente. No hay contraseñas universales. Los valores `replace-...` del ejemplo deben sustituirse antes del seed. Los archivos `.env` son privados y están excluidos de Git y del ZIP de entrega.

En el equipo donde se preparó esta entrega ya se crearon una base de aplicación y una base de pruebas aisladas en XAMPP (MariaDB, puerto 3310). `apps/api/.env` contiene únicamente la configuración local generada para este proyecto. Las cuentas de gestor y líder usan los correos y contraseñas de ese archivo. Puedes crear tu propia cuenta de aprendiz en la vista previa.

## Flujos disponibles

- Aprendiz: registro, sesión, microlecciones secuenciales, desafíos evaluados en el servidor, simulaciones de varios días, historial, nivel, logros, progreso y edición de perfil.
- Líder: registro y edición de aprendices propios, desactivación/reactivación, grupos, asignación de integrantes, informe agregado y detalle por temática.
- Gestor: creación/edición/orden de módulos y lecciones, importación de texto `.txt`, vinculación de videos por ID de YouTube, desafíos y escenarios configurables.

El paquete contiene nueve módulos, nueve microlecciones, nueve desafíos y dos escenarios. Los temas corresponden al SRS adjunto. El material es introductorio y requiere revisión pedagógica antes de una capacitación empresarial real.

## Arquitectura

```text
View React → hooks / Zustand → services HTTP → API Express
                                               ↓
                                     middleware JWT + roles
                                               ↓
                                     controller → service
                                               ↓
                                    repositorio / Prisma → MySQL

React / Zustand → adaptador de eventos → Phaser (representación e interacción)
Decisión del usuario → API → evaluación y persistencia → nuevo estado → Phaser
```

`apps/web/src/pages` y `components` son vistas; `hooks` y `stores` son ViewModels; `types` define DTOs; `services` encapsula HTTP. Phaser se carga cuando inicia una partida, no en el acceso ni en la ruta de lecciones.

`apps/api/src/repositories` centraliza el cliente Prisma y consultas reutilizadas. Los servicios coordinan reglas y transacciones; los controladores validan DTOs y devuelven respuestas. La migración inicial vive en `apps/api/prisma/migrations`.

Consulta [arquitectura y decisiones](docs/ARQUITECTURA.md), [contrato de API](docs/API.md), [verificación](docs/VERIFICACION.md) y [despliegue](docs/DESPLIEGUE.md).

## Comandos

| Comando              | Propósito                                                         |
| -------------------- | ----------------------------------------------------------------- |
| `npm run dev`        | API y Vite en desarrollo                                          |
| `npm run build`      | Generación Prisma, TypeScript y compilación frontend              |
| `npm run lint`       | ESLint en ambos proyectos                                         |
| `npm test`           | Pruebas unitarias, de componentes y flujos con dobles controlados |
| `npm run db:migrate` | Aplicar migraciones existentes; no resetear datos                 |
| `npm run db:seed`    | Crear contenido y cuentas iniciales opcionales                    |

Las pruebas de integración real requieren `RUN_DB_TESTS=1` y un `DATABASE_URL` cuya base empiece con `sq_test_` o `stockquest_test`. Utiliza una base de pruebas vacía y aplica las migraciones antes. GitHub Actions proporciona MySQL 8 efímero y ejecuta estas pruebas automáticamente.

En esta sesión de Windows el empaquetador nativo encontró restricciones al cargar su configuración. La compilación se verificó con `npm run build -w @stock-quest/web -- --configLoader native`, `GOMAXPROCS=2` y `GOMEMLIMIT=512MiB`. La vista previa usa el build, con `npm exec -w @stock-quest/web -- vite preview --host 127.0.0.1 --port 5173 --configLoader native`; la API se inicia con `npm run start -w @stock-quest/api`. Usa `FRONTEND_URL=http://127.0.0.1:5173` para esa dirección.

## Alcance de la entrega

La implementación y las pruebas locales están disponibles. El despliegue público, la base de demostración en Clever Cloud y las credenciales de GitHub/Vercel/Render no están configurados: requieren cuentas del propietario. Los archivos de despliegue y CI están incluidos. No se garantiza el objetivo de 99 % de disponibilidad ni el límite de 3 segundos sin medir el entorno alojado.
