import { config } from "dotenv";
import { PrismaClient } from "@prisma/client";

// An optional file is read only for this process; the application .env is unchanged.
const args = process.argv.slice(2);
if (args.length && (args.length !== 2 || args[0] !== "--env")) {
  console.error("Uso: npm run db:check -- --env RUTA_ABSOLUTA_AL_ENV");
  process.exit(1);
}
const loaded = config(args.length ? { path: args[1], override: true } : {});
if (args.length && loaded.error) {
  console.error("No se pudo leer el archivo de configuración indicado.");
  process.exit(1);
}
try {
  const url = new URL(process.env.DATABASE_URL ?? "");
  if (url.protocol !== "mysql:" || !url.hostname || url.pathname.length < 2) {
    throw new Error();
  }
} catch {
  console.error("Configura DATABASE_URL con formato mysql://USUARIO:CONTRASEÑA@HOST:PUERTO/BASE.");
  process.exit(1);
}
const db = new PrismaClient();
try {
  await db.$connect();
  await db.$queryRaw`SELECT 1`;
  const status = await db.$queryRaw`SHOW SESSION STATUS LIKE 'Ssl_cipher'`;
  console.log("Conexión MySQL verificada. No se modificaron datos.");
  console.log(status.some(row => Boolean(row.Value)) ? "Transporte TLS: activo." : "Transporte TLS: no activo en esta conexión.");
} catch (error) {
  const hints = {
    P1000: "Credenciales rechazadas. Revisa usuario y contraseña.",
    P1001: "Servidor no accesible. Revisa host, puerto y la lista de IP permitidas.",
    P1002: "Tiempo de conexión agotado. Revisa la red y connect_timeout.",
    P1003: "La base indicada no existe.",
    P1010: "El usuario no tiene acceso a la base indicada.",
    P1011: "No se pudo establecer TLS. Revisa el certificado del proveedor.",
    P1013: "URL inválida. Codifica los caracteres especiales del usuario y contraseña.",
  };
  // Do not log the raw error: it can contain connection details.
  console.error(hints[error.errorCode ?? error.code] ?? "No se pudo verificar la conexión. Revisa DATABASE_URL y la configuración del proveedor.");
  process.exitCode = 1;
} finally {
  await db.$disconnect();
}
