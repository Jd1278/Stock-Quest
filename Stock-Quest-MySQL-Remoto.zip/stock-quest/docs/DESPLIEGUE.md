# Despliegue

## Frontend: Vercel

Importa el repositorio desde la raíz. `vercel.json` define instalación, build, directorio y fallback de React Router. Configura `VITE_API_URL=https://TU-API/api` antes del build. Solo es una URL pública, nunca una contraseña. El cambio de esta variable requiere recompilar.

## Backend: Render

`render.yaml` describe un servicio Node que instala, compila y aplica migraciones. Configura `DATABASE_URL` del proveedor MySQL, `FRONTEND_URL` con el origen exacto de Vercel y un `JWT_SECRET` aleatorio. Render asigna `PORT`. No copies los secretos locales al repositorio.

El JWT y bcrypt se ejecutan en Express. Se mantiene una sola instancia para el limitador en memoria del MVP. Si se escala horizontalmente, migra el limitador a un almacenamiento compartido y define la topología de proxy antes de cambiar `trust proxy`.

## MySQL de demostración

Crea la instancia en Clever Cloud o un proveedor MySQL compatible. Usa la conexión y TLS según la configuración del proveedor. Aplica `npm run db:migrate` con la URL de destino; no uses `db push`, `migrate reset` ni SQL manual en producción. El seed es una acción inicial, no parte de cada arranque.

No se aprovisionó una cuenta cloud ni se contrataron servicios durante esta entrega. El puerto local 3310 corresponde a XAMPP/MariaDB; no es la base cloud.

## GitHub Actions

El job `verify` instala con lockfile, genera Prisma, aplica la migración en MySQL 8 efímero, ejecuta lint, Jest/RTL/Supertest e integración y compila. Los valores de autenticación de ese job son exclusivamente fixtures de CI, no credenciales de un entorno real.

Para activar el job `deploy`:

1. Configura el environment `production` y su política de revisión.
2. Añade GitHub Secrets `DATABASE_URL`, `FRONTEND_DEPLOY_HOOK` (Vercel) y `BACKEND_DEPLOY_HOOK` (Render).
3. Define la variable de repositorio `DEPLOY_ENABLED=true`.
4. Desactiva despliegues automáticos del proveedor que no esperen al pipeline y vincula los hooks a la rama `main`.

El job aplica migraciones y solicita ambos despliegues después de `verify`. Un hook aceptado no confirma que el despliegue terminó: revisa el estado final y los logs de ambos proveedores. No se afirma que este pipeline haya corrido en GitHub; sus archivos se entregan configurados.

## Comprobaciones antes de publicar

Prueba registro y login por HTTPS, origen CORS, rol correcto, recepción de pedidos, persistencia después de reiniciar la API, sesión revocada, y video del canal del proyecto. Mide lecciones y carga inicial de Phaser bajo 10 Mbps; verifica Chrome, Edge, Firefox, Safari y móvil. Configura monitorización y copias de seguridad para evaluar la disponibilidad objetivo del 99 %.

Consulta técnica: [migraciones Prisma en desarrollo y producción](https://docs.prisma.io/docs/orm/v6/prisma-migrate/workflows/development-and-production), [ciclo de vida de Phaser](https://docs.phaser.io/phaser/concepts/game).
