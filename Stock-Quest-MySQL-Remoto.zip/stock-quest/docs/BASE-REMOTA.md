# Conectar Stock Quest a MySQL remoto

La API usa `DATABASE_URL` y Prisma con proveedor MySQL: puede conectarse tanto a XAMPP local como a un host remoto. React sigue llamando a la API; las credenciales permanecen en el servidor. No se necesita modificar tablas ni componentes para cambiar de host.

## Configuración

En `apps/api/.env`, o en las variables del servicio que aloja Express, configura la conexión proporcionada por tu proveedor:

```dotenv
DATABASE_URL="mysql://USUARIO:CLAVE_CODIFICADA@HOST:3306/BASE?connect_timeout=15&connection_limit=5&sslaccept=strict"
```

Reemplaza usuario, contraseña, host, puerto y base. Codifica los caracteres especiales del usuario y contraseña (por ejemplo, `@` como `%40`); no codifiques la URL completa. Conserva los parámetros específicos indicados por el proveedor.

Para TLS configura el certificado CA del proveedor cuando sea necesario mediante `sslcert`. Las rutas relativas se resuelven desde `apps/api/prisma`; puedes usar una ruta absoluta con barras `/`. `sslaccept=strict` valida el certificado; no sustituye la configuración TLS del servidor. Exige conexiones cifradas en el servidor remoto y comprueba que el diagnóstico indica TLS activo. No guardes certificados privados ni claves en Git.

El proveedor debe permitir conexiones desde la IP del backend (o de este equipo si la API corre aquí). No es necesario abrir la base a todos los orígenes. `FRONTEND_URL` controla CORS de la API y no determina la dirección de MySQL.

## Verificar antes de cambiar la aplicación

Puedes preparar un archivo privado fuera del código con solo `DATABASE_URL` y probarlo desde la raíz del proyecto:

```powershell
npm run db:check -- --env "C:/ruta/privada/stockquest-remoto.env"
```

Ese comando usa el archivo únicamente para su proceso, sin sobrescribir `apps/api/.env`. Ejecuta `SELECT 1` y consulta el estado TLS; no crea tablas, migra datos ni imprime credenciales. Si omites `--env`, usa la configuración del backend y las variables del proceso:

```powershell
npm run db:check
```

## Activar la conexión

Después de comprobarla, configura esa misma `DATABASE_URL` en `apps/api/.env` o en el entorno de Express y reinicia la API. No existe un cambio automático por ejecutar `db:check --env`.

Si la base remota es nueva y exclusiva para Stock Quest, aplica la migración existente:

```powershell
npm run db:migrate
npm run db:seed
npm run start -w @stock-quest/api
```

Estos comandos usan la configuración activa del backend, no recuerdan el archivo pasado al diagnóstico. En una base ya existente, revisa su esquema e historial antes de migrar. No uses `migrate reset`.

Cambiar la conexión no traslada los usuarios ni resultados locales. La transferencia de datos existentes requiere una exportación/importación planificada; el seed solo crea contenido inicial y cuentas opcionales.

Referencia: [conector MySQL de Prisma 6: URL y TLS](https://docs.prisma.io/docs/orm/v6/overview/databases/mysql).

## Obtener la conexión en Clever Cloud

En la consola de Clever Cloud crea un add-on MySQL, o abre el que ya tengas. Elige el plan y región según tus necesidades. La sección de información o variables del add-on proporciona:

| Variable Clever Cloud | Parte de DATABASE_URL |
|---|---|
| MYSQL_ADDON_HOST | HOST |
| MYSQL_ADDON_PORT | PUERTO |
| MYSQL_ADDON_DB | BASE |
| MYSQL_ADDON_USER | USUARIO |
| MYSQL_ADDON_PASSWORD | CONTRASEÑA (codificada para URL) |

Guarda esos valores en privado. Construye `DATABASE_URL` con ellos y sigue el diagnóstico anterior. No copies literalmente `DATABASE_URL=$MYSQL_ADDON_URI` en un archivo dotenv: esta aplicación no hace expansión de variables dentro de sus valores.

Estado actual: conexión local conservada; conexión Clever Cloud pendiente de aprovisionar y configurar. El diagnóstico se probó contra la base local, sin alterar datos; ESLint pasó. No se ha probado ningún servidor remoto.

Fuentes: [MySQL en Clever Cloud](https://www.clever.cloud/developers/doc/deploy/databases/mysql) y [variables del add-on](https://www.clever.cloud/developers/doc/develop/common-configuration/environment-variables/reference/).
